use mssba1;
CREATE TABLE bookprofile (
BookID int NOT NULL,
BookName varchar(25),
BookPrice int,
BookPublisherName varchar(25),
BookYearOfPublication int,
PRIMARY KEY (BookID)
);