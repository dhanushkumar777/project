package utility;

import java.sql.Connection;
import java.sql.Statement;
import java.util.Scanner;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import entity.BookInfo;

public class Connectm {
public static boolean isinserted(int bid, String bname, int bprice, String bpublisher, int byear)
{
	boolean flag=true;
	try 
	{
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mssba1","root","root");
		Statement st = conn.createStatement();
		String query = "Insert into bookprofile values(?,?,?,?,?)";
		PreparedStatement ps = conn.prepareStatement(query);
		ps.setInt(1, bid);
		ps.setString(2, bname);
		ps.setInt(3, bprice);
		ps.setString(4, bpublisher);
		ps.setInt(5, byear);
		//System.out.println("Query is "+query);
		int x = ps.executeUpdate();
		if(x!=0)
			flag=true;
		else
			flag=false;
		
		conn.close();
		st.close();
		
	}
	catch(Exception ex)
	{
		System.out.println("Exception caught while inserting "+ex);
		flag=false;
	}
	return flag;
	
}

public static boolean isUpdated(int bid, String bname, int bprice, String bpublisher, int byear)
{
	boolean flag=true;
	try 
	{
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mssba1","root","root");
		Statement st = conn.createStatement();
		String query = "update bookprofile set BookName='"+bname+"',BookPrice='"+bprice+"',BookPublisherName='"+bpublisher+"',BookYearOfPublication='"+byear+"' where BookID='"+bid+"'";
	
		int x = st.executeUpdate(query);
		if(x!=0)
			flag=true;
		else
			flag=false;
		
		conn.close();
		st.close();
		
	}
	catch(Exception ex)
	{
		System.out.println("Exception caught while updating "+ex);
		flag=false;
	}
	return flag;
	
}

public static boolean isDeleted(int bid)
{
	boolean flag=true;
	try 
	{
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mssba1","root","root");
		Statement st = conn.createStatement();
		String query = "delete from bookprofile where BookID='"+bid+"'";
	
		int x = st.executeUpdate(query);
		if(x!=0)
			flag=true;
		else
			flag=false;
		
		conn.close();
		st.close();
		
	}
	catch(Exception ex)
	{
		System.out.println("Exception caught while deleting "+ex);
		flag=false;
	}
	return flag;
	
}

public static boolean isDisplayAll()
{
	boolean flag=true;
	try 
	{
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mssba1","root","root");
		Statement st = conn.createStatement();
		ResultSet rs = st.executeQuery("select * from bookprofile");
		while(rs.next())
		{
			System.out.println(rs.getInt("BookID")+"\t"+rs.getString("BookName")+"\t"+rs.getInt("BookPrice")+"\t"+rs.getString("BookPublisherName")+"\t"+rs.getInt("BookYearOfPublication"));
		}
		
		conn.close();
		st.close();
		
	}
	catch(Exception ex)
	{
		System.out.println("Exception caught while displaying "+ex);
		flag=false;
	}
	return flag;
	
}

public static boolean isDisplayOne(int bid)
{
	boolean flag=true;
	try 
	{
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mssba1","root","root");
		Statement st = conn.createStatement();
		ResultSet rs = st.executeQuery("select * from bookprofile where BookID='"+bid+"'");
		while(rs.next())
		{
			System.out.println(rs.getInt("BookID")+"\t"+rs.getString("BookName")+"\t"+rs.getInt("BookPrice")+"\t"+rs.getString("BookPublisherName")+"\t"+rs.getInt("BookYearOfPublication"));
		}
		
		conn.close();
		st.close();
		
	}
	catch(Exception ex)
	{
		System.out.println("Exception caught while displaying "+ex);
		flag=false;
	}
	return flag;
	
}

public static void main(String args[])
{
	Scanner sc = new Scanner(System.in);
	Scanner scc = new Scanner(System.in);
	int cont=0;
	do
	{
		System.out.println("Your choices are \n1.Insert Details \n2.Update Details \n3.Delete Details \n4.DisplayAll Details \n5.Display Particular Book Details \n6.Exit");
		System.out.println("Enter your Choice: ");
		int ch = sc.nextInt();
		switch(ch)
		{
		case 1:System.out.println("Enter Book id:");
				int bid = sc.nextInt();
				System.out.println("Enter the Name of Book:");
				String bname = scc.nextLine();
				System.out.println("Enter the Price of Book:");
				int bprice = sc.nextInt();
				System.out.println("Enter the Publisher Name: ");
				String bpublisher = scc.nextLine();
				System.out.println("Enter the Year of Publication: ");
				int byear = sc.nextInt();
				BookInfo bi = new BookInfo();
				bi.setBid(bid);
				bi.setBname(bname);
				bi.setBprice(bprice);
				bi.setBpublisher(bpublisher);
				bi.setByear(byear);
				boolean flag = true;
				flag = isinserted(bid,bname,bprice,bpublisher,byear);
				if(flag)
					System.out.println("Data Inserted Successfully!!");
				else
					System.out.println("Error occured while inserting");
		break;
		case 2:System.out.println("Enter Book id:");
				int bid1 = sc.nextInt();
				System.out.println("Enter the Name of Book:");
				String bname1 = scc.nextLine();
				System.out.println("Enter the Price of Book:");
				int bprice1 = sc.nextInt();
				System.out.println("Enter the Publisher Name: ");
				String bpublisher1 = scc.nextLine();
				System.out.println("Enter the Year of Publication: ");
				int byear1 = sc.nextInt();
				BookInfo bi1 = new BookInfo();
				bi1.setBid(bid1);
				bi1.setBname(bname1);
				bi1.setBprice(bprice1);
				bi1.setBpublisher(bpublisher1);
				bi1.setByear(byear1);
				boolean flag1=true;
				flag1 = isUpdated(bid1,bname1,bprice1,bpublisher1,byear1);
				if(flag1)
					System.out.println("Data Updated Successfully!!");
				else
					System.out.println("Error occured while updating");
				break;
		case 3:System.out.println("Enter Book id you want to delete:");
				int bid2 = sc.nextInt();
		
				boolean flag2=true;
				flag2 = isDeleted(bid2);
				if(flag2)
					System.out.println("Data Deleted Successfully!!");
				else
					System.out.println("Error occured while deleting");
				break;
		case 4: System.out.println("All the Book details are ");
				isDisplayAll();
				break;
		case 5: System.out.println("Enter Book id you want to display:");
				int bid4 = sc.nextInt();
				isDisplayOne(bid4);
				break;
		case 6: System.exit(0);
				break;
		case 7: System.out.println("Invalid Input");
				break;
				
		}
		System.out.println("Do You want to continue 1 for yes and 0 for no");
		cont = sc.nextInt();
	}while(cont==1);
}
}
